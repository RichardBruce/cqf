#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

const double PI = 3.14159265358979323846;
const double SQRT_2PI_INV = 1.0 / std::sqrt(2.0 * PI);


#endif
